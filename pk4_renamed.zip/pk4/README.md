# pk4

Applicazione Tkinter **PrintK v 4.0**

## Avvio rapido
```bash
python Pk4.0.py
```
> Se su Linux manca Tk: `sudo apt install python3-tk`

## Comandi Git (inizializzazione e primo push)
> Sostituisci l'URL con il tuo se necessario.
```bash
echo "# pk4" >> README.md
git init
git add README.md Pk4.0.py .gitignore
git commit -m "primo commit"
git branch -M main
git remote add origin https://github.com/AlbaPanico/pk4.git
git push -u origin main
```

## Note
- Il file `configurazione.json` viene salvato nella tua HOME alla prima modifica in *Impostazioni*.
- Log errori (se abilitati in future versioni) su `printk_error.log`.
